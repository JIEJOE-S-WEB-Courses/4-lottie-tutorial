/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global $, Folder, File, app */

$.__bodymovin.bm_reportMessageTypes = (function () {

    return {
        WARNING: 'warning',
        ERROR: 'error',
    };
}());