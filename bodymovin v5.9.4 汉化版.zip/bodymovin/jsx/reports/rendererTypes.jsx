/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global $, Folder, File, app */

$.__bodymovin.bm_reportRendererTypes = (function () {

    return {
        BROWSER: 'browser',
        IOS: 'ios',
        ANDROID: 'android',
        SKOTTIE: 'skottie',
    };
}());