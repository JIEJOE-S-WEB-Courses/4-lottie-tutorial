$.__bodymovin.maskTypes = {
    NONE: 'n',
    ADD: 'a',
    SUBTRACT: 's',
    INTERSECT: 'i',
    LIGHTEN: 'l',
    DARKEN: 'd',
	DIFFERENCE: 'f',
}