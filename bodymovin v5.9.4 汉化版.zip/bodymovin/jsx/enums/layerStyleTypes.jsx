$.__bodymovin.layerStyleTypes = {
	stroke: 0,
    dropShadow: 1,
    innerShadow: 2,
    outerGlow: 3,
    innerGlow: 4,
    bevelEmboss: 5,
    satin: 6,
    colorOverlay: 7,
    gradientOverlay: 8,
}